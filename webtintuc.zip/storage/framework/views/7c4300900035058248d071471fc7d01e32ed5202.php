<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="/asset/backend/lib/chart/chart.min.js"></script>
    <script src="/asset/backend/lib/easing/easing.min.js"></script>
    <script src="/asset/backend/lib/waypoints/waypoints.min.js"></script>
    <script src="/asset/backend/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="/asset/backend/lib/tempusdominus/js/moment.min.js"></script>
    <script src="/asset/backend/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="/asset/backend/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="/asset/backend/js/main.js"></script>
<?php /**PATH C:\wamp64\www\webtintuc\resources\views/admin/layouts/script.blade.php ENDPATH**/ ?>