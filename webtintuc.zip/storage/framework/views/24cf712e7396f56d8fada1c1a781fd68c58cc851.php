
<?php $__env->startSection('content'); ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-md-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Quản lý tin tuc</h6>

                <?php if(session()->has('mess')): ?>
                <p class="alert alert-primary sm-4">
                    <?php echo e(session('mess')); ?>

                </p>
                <?php endif; ?>
                <table class="table table-striped table-bordered table-hover" >
                    <thead>
                        <tr>
                            <th scope="col">ID</th>
                            <th scope="col">Tiêu đề</th>
                            <th scope="col">Mô tả</th>
                            <th scope="col" >Nội dung</th>
                            <th scope="col">Ngày đăng</th>
                            <th scope="col">Nhóm tin</th>
                            <th scope="col">Loại tin</th>
                            <th scope="col">Lượt xem</th>
                            <th scope="col">HOT</th>
                            <th></th>

                        </tr>
                    </thead>
                    <?php $__currentLoopData = $tintuc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody >
                        <tr >
                            <td><?php echo e($item->idtintuc); ?></td>
                            <td><div><?php echo e($item->tieude); ?></div>
                                <img width="100px" src="<?php echo e(asset('storage/public_img/'.$item->img)); ?>" />
                            </td>
                            <td ><span><?php echo e($item->mota); ?></span></td>
                            <td ><?php echo e($item->noidung); ?></td>
                            <td><?php echo e($item->ngaydang); ?></td>
                            <td><?php echo e($item->loaitin->nhomtin->tennhomtin); ?></td>
                            <td><?php echo e($item->loaitin->tenloaitin); ?></td>
                            <td><?php echo e($item->luotxem); ?></td>
                            <td>
                                <?php if($item->hot==0): ?>
                                <?php echo e('Không'); ?>

                                <?php else: ?>
                                <?php echo e('Có'); ?>

                                <?php endif; ?>
                            </td>
                            <th>
                                <form action="/admin/tintuc/destroy/<?php echo e($item->idtintuc); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="delete">
                                    <input type="submit" value="xóa" class="btn btn-danger">
                                </form>
                            </th>
                            <th>
                                <a href="/admin/tintuc/edit/<?php echo e($item->idtintuc); ?>" class="btn btn-success"> sửa</a>
                            </th>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
                    
                    
                </table>
                <div class="" style="float: right;"> <?php echo e($tintuc->links()); ?></div>
            </div>
        </div>

    </div>
</div>
<!-- Table End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/admin/tintuc/index.blade.php ENDPATH**/ ?>