<div class="col-lg-4 col-md-4 col-sm-4">
        <aside class="right_content">
          <div class="single_sidebar">
            <h2><span>Popular Post</span></h2>
            <ul class="spost_nav">
              <?php $__currentLoopData = $tinnoibat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <li>
                <div class="media wow fadeInDown"> <a  class="media-left"> <img alt="" src="<?php echo e(asset('storage/public_img/'.$item->img)); ?>"> </a>
                  <div class="media-body"> <a href="/tintuc/<?php echo e($item->idtintuc); ?>" class="catg_title"> <?php echo e($item->tieude); ?></a> </div>
                </div>
              </li>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
          </div>
        </aside>
      </div><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/layouts/contentRight.blade.php ENDPATH**/ ?>