
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('clients.layouts.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<section id="contentSection">
    <div class="row">
      <div class="col-lg-8 col-md-8 col-sm-8">
        <div class="left_content">
          <div class="single_page">
            <ol class="breadcrumb">
              <li><a href="../index.html">Home</a></li>
              <li><a href="#"><?php echo e($tintuc->loaitin->nhomtin->tennhomtin); ?></a></li>
              <li class="active"><?php echo e($tintuc->loaitin->tenloaitin); ?></li>
            </ol>
            <h1><?php echo e($tintuc->tieude); ?></h1>
            <div class="post_commentbox"> <a href="#"><i class="fa fa-user"></i>VanDepTrai</a> <span><i class="fa fa-calendar"></i><?php echo e($tintuc->ngaydang); ?></span> <a href="/loaitin/<?php echo e($tintuc->idloaitin); ?>"><i class="fa fa-tags"></i><?php echo e($tintuc->loaitin->tenloaitin); ?></a> </div>
            <div class="single_page_content"> <img class="img-center" src="<?php echo e(asset('storage/public_img/'.$tintuc->img)); ?>" alt="">
              <p><?php echo $tintuc->mota; ?></p>
              <blockquote> <?php echo $tintuc->noidung; ?> </blockquote>
          
              
           
            </div>
        
          
          </div>

          <div >
              <h4>Viết bình luận ...<span class="glyphicon-pencil"></span></h4>

              <form role="form" action="/<?php echo e($tintuc->idtintuc); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <textarea class="form-control" name="noidung" rows="3" required></textarea>

                </div>
                
                <button type="submit" class="btn btn-primary">Gửi</button>
                
              </form>
          </div>
          <?php $__currentLoopData = $tintuc->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          
          <div >
              <a class="pull-left" href="#">
                <img class="media-object" src="http://placehold.it/40x40" alt="">
              </a>
              <div class="media-body">
                <h4 class="media-heading"><?php echo e($cm->user->ten); ?>

                  <small><?php echo e($cm->ngaydang); ?></small>
                </h4>
                <?php echo e($cm->noidung); ?>


              </div>
          </div>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


  
        </div>
      </div>
        <div>
        </div>
        <div>
        </div>
        </a> </nav>
        <?php echo $__env->make("clients.layouts.contentRight", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('clients/layouts/masteru', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/clients/pages/tintuc.blade.php ENDPATH**/ ?>