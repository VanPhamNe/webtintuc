
<?php $__env->startSection('content'); ?>
<!-- Table Start -->
<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-md-12">
            <div class="bg-light rounded h-100 p-4">
                <h6 class="mb-4">Quản lý loại tin</h6>
                
                <?php if(session()->has('mess')): ?>
                <p class="alert alert-primary sm-4">
                    <?php echo e(session('mess')); ?>

                </p>
                <?php endif; ?>
                <table class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                            <th scope="col">ID loại tin</th>
                            <th scope="col">Tên loại tin</th>
                            <th scope="col">Nhóm tin</th>
                            <th></th>

                        </tr>
                    </thead>
                    <?php $__currentLoopData = $loaitin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tbody>
                        <tr>
                            <td><?php echo e($item->idloaitin); ?></td>
                            <td><?php echo e($item->tenloaitin); ?></td>
                            <td><?php echo e($item->nhomtin->tennhomtin); ?></td>
                            <th>
                                <form action="/admin/loaitin/destroy/<?php echo e($item->idloaitin); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="_method" value="delete">
                                    <input type="submit" value="xóa" class="btn btn-danger">
                                </form>
                            </th>
                            <th>
                                <a href="/admin/loaitin/edit/<?php echo e($item->idloaitin); ?>" class="btn btn-success"> sửa</a>
                            </th>
                            </td>
                        </tr>
                    </tbody>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </table>
            </div>
        </div>

    </div>
</div>
<!-- Table End -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/layouts/masterad', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\webtintuc\resources\views/admin/loaitin/index.blade.php ENDPATH**/ ?>